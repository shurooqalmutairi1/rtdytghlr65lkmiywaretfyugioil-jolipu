<?php
class UsersInfo
{
	private $db = null; 
	private $encriptOb = null;
	
	function __construct()
	{
		$this->db = new DB();
		$this->encriptOb = new AES();
	}
	
	function insertNew($user_id , $title, $info)
	{
		$title = $this->encriptOb-> encrypt($title);
		$info = $this->encriptOb-> encrypt($info);  
		$sql = "INSERT INTO user_info ( user_id , title, info, addDate) 
					VALUES ('$user_id' , '$title',  '$info', now())";
		return $this->db->executeNonQuery($sql);
	}
	
	function editUserInfo($user_id , $title, $info , $info_id)
	{
		$title = $this->encriptOb-> encrypt($title);
		$info = $this->encriptOb-> encrypt($info); 
		$sql = "update user_info set title = '$title', info = '$info' 
					where user_id = '$user_id' and id = '$info_id'";
		return $this->db->executeNonQuery($sql);
	}
	
	function deleteUserInfo($user_id, $id)
	{
		$sql = "delete from user_info where id = '$id' and user_id='$user_id'";
		return $this->db->executeNonQuery($sql);
	}
	
	function getUserInfo($id)
	{
		$sql = "select * from user_info where id = '$id'";		 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			return $row = $result->fetch_assoc();
		}else{
			return 0;
		}
		
	}
	
	function showUserInfosTable($user_id)
	{
		$data="";
		$sql = "select * from user_info where user_id = '$user_id'"; 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			while($row = $result->fetch_assoc()) 
			{
				$data = $data . "<tr>";
				$data = $data . " <td>".$this->encriptOb-> dencrypt($row["title"])."</td>";  
				$data = $data . " <td> <a href='viewUserInfo.php?info_id=".$row["id"]."'>View</a></td>"; 
				$data = $data . "</tr>";
			}
			return $data;
		}
		else
			return "<tr><td colspan=3>No User Info in DB</td></tr>";
	}
	
}

?>