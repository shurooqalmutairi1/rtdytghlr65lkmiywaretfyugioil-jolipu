<?php

/*used to add the user's accounts, and generates passwords for his accounts.*/
/*using three function’s (insert , edit , and delete) account */
class Account
{
	private $db = null; 
	private $encriptOb = null;
	
	function __construct()
	{
		$this->db = new DB();
		$this->encriptOb = new AES();
	}
	
	
	
	function insertNew($user_id , $account_name, $email, $password, $notes) /*First we have to encrypt the inserted information’s then  we store it in the data base.*/
	{
		$account_name = $this->encriptOb-> encrypt($account_name);
		$email = $this->encriptOb-> encrypt($email);
		$password = $this->encriptOb-> encrypt($password);
		$notes = $this->encriptOb-> encrypt($notes);
		$sql = "INSERT INTO accounts ( user_id , account_name, email, password, notes) 
					VALUES ('$user_id' , '$account_name',  '$email', '$password', '$notes')";
		return $this->db->executeNonQuery($sql);
	}
	
	function editAccount($user_id , $account_name, $email, $password, $notes , $account_id)/*First we encrypt the edited information’s then we store it in the data base.*/
	{
		$account_name = $this->encriptOb-> encrypt($account_name);
		$email = $this->encriptOb-> encrypt($email);
		$password = $this->encriptOb-> encrypt($password);
		$notes = $this->encriptOb-> encrypt($notes);
		$sql = "update accounts set account_name = '$account_name', email = '$email', password = '$password', notes = '$notes' 
					where user_id = '$user_id' and id = '$account_id'";
		return $this->db->executeNonQuery($sql);
	}
	
	function deleteAccount($user_id, $id)/*Delete the account from the data base.*/
	{
		$sql = "delete from accounts where id = '$id' and user_id='$user_id'";
		return $this->db->executeNonQuery($sql);
	}
	
	function getAccount($id)
	{
		$sql = "select * from accounts where id = '$id'";		 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			return $row = $result->fetch_assoc();
		}else{
			return 0;
		}
		
	}
	
	function showAccountsTable($user_id)
	{
		$data="";
		$sql = "select * from accounts where user_id = '$user_id'"; 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			while($row = $result->fetch_assoc()) 
			{
				$data = $data . "<tr>";
				$data = $data . " <td>".$this->encriptOb-> dencrypt($row["account_name"])."</td>";  
				$data = $data . " <td> <a href='viewAccount.php?account_id=".$row["id"]."'>View</a></td>"; 
				$data = $data . "</tr>";
			}
			return $data;
		}
		else
			return "<tr><td colspan=3>No Accounts in DB</td></tr>";
	}
	
}

?>