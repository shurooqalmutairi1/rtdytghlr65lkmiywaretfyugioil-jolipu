<?php
class User
{
	private $db = null;
	private $userID = 0;
	private $email = "";
	private $code = "";
	private $isActive = 1;
	private $isExpaireCode = false;
	
	function __construct($db)
	{
		$this->db = $db;
	}
	
	function userLogin($email, $pass)
	{
		
		$sql = "select * from users where email = '$email' and `password`  = MD5('$pass')";
		 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			while($row = $result->fetch_assoc()) 
			{
				$this->setUserID($row["id"]);
				$this->setEmail($row["email"]);
				$this->setActive($row["active"]); 
				if($row["active"] == 0)
				{
					return 0;
				}
			}
			return 1;
		}else{
			return 0;
		}
	} 
	
	function getUser($userID)
	{ 
		$sql = "select * from users where id = '$userID'"; 
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			while($row = $result->fetch_assoc()) 
			{
				return $row;
			} 
		}
		return array();
	} 
	
	
	function userSingup($name, $email, $pass)
	{
		
		$sql = "insert into users(name, email, `password`) values('$name', '$email', MD5('$pass'))";
		
		return $this->db->executeNonQuery($sql);
		
	} 
	
	function updateData($name, $email, $pass, $userID)
	{
		
		$sql = "update users set name = '$name',  email =  '$email' , `password` = MD5('$pass') where id = '$userID'"; 
		
		return $this->db->executeNonQuery($sql);
		
	} 
	
	function generateCode(){
		$userID = $this->getUserID();
		$six_digit_random_number = mt_rand(100000, 999999);
		$sql = "insert into login_request (user_id, req_time, code) values ('$userID', now(), '$six_digit_random_number')";
		 
		if($this->db->executeNonQuery($sql))
		{
			$this->setCode($six_digit_random_number);
			return true;
		}else{
			return false;
		}
	}
	
	
	function checkCode($code , $user_id)
	{
		
		$sql = "select * from login_request where code = '$code' and user_id = '$user_id'";
		
		$result = $this->db->executeQuery($sql);
		
		if(gettype($result) == "object")
		{
			while($row = $result->fetch_assoc()) 
			{
				$this->setUserID($row["user_id"]); 
				
				$req_time = new DateTime($row["req_time"]);
				$time_now = new DateTime();
				$since_start = $req_time->diff($time_now);  
				if ($since_start->i >= 5 ) {
					$this->isExpaireCode = true;
				}  
			}
			return 1;
		}else{
			return 0;
		}
	} 
	
	
	function getUserID()
	{
		return $this->userID;
	}
	
	function setUserID($userID)
	{
		$this->userID = $userID;
	}
	
	function getEmail()
	{
		return $this->email;
	}
	
	function setEmail($email)
	{
		$this->email = $email;
	}
	
	function isActive()
	{
		return ($this->isActive == 1) ? true : false ;
	}
	
	function setActive($active)
	{
		$this->isActive = $active;
	}
	
	function getCode()
	{
		return $this->code;
	}
	
	function setCode($code)
	{
		$this->code = $code;
	}
	
	function getIsExpaireCode()
	{
		return $this->isExpaireCode;
	}
	
	
	function getRecoverByID($id){
		$query = "SELECT * FROM `recover_req` where id = '$id' ";
		$data = array();
		
		$result = $this->db->executeQuery($query);
		$id = 0;
		if(gettype($result) == "object")
		{
			while($row = mysqli_fetch_array($result))
			{
				$data["id"] = $row["id"];
				$data["email"] = $row["email"];
				$data["req_time"] = $row["req_time"];
			}
		}
		return $data;
	}
	
	function getUserIdByEmail($email)
	{
		$sql = "select * from users where email = '$email'";
		$result = $this->db->executeQuery($sql);
		$id = 0;
		if(gettype($result) == "object")
		{ 
			while($row = mysqli_fetch_array($result))
			{
				$id  = $row["id"]; 
			}
		}
		return $id;
	}
	
	function addToRecoveryRequest($email ){
		$sql = " insert into recover_req (email , req_time) values ('$email', now() );";
		$this->db->executeNonQuery($sql);
		return  $this->db->getLastID();
	}
	
	function updatePassword($email, $password)
	{ 
		$sql = "update users set  
								`password` = MD5('$password'), active = '1' where email = '$email'";

		return $this->db->executeNonQuery($sql);
	}
	
	function blockAccount($email){
		$sql = "update users set active = '0' where email = '$email'"; 
		return $this->db->executeNonQuery($sql);
	}
}

?>