<?php
//https://www.phpcluster.com/aes-encryption-and-decryption-in-php/
class AES
{
	
	private $cipherType = "aes-256-cbc"; 
	//Generate a 256-bit encryption key 
	//https://www.allkeysgenerator.com/Random/Security-Encryption-Key-Generator.aspx
	private $encryption_key = "w!z%C&F)J@NcRfUjXn2r5u8x/A?D(G-K"; 
	//16 byte initial vector
	private $iv = "wefqsv/asdfBM1BQ"; 
	
	function __construct()
	{ 
	}
	
	function encrypt($data){
		return openssl_encrypt($this->safehtml($data), $this->cipherType, $this->encryption_key, 0, $this->iv); 
	}
	
	function dencrypt($encrypted_data){
		return openssl_decrypt($encrypted_data , $this->cipherType, $this->encryption_key, 0, $this->iv); 
	}	
	 
	function safehtml($s)
	{
		$s=str_replace("&", "&amp;", $s);
		$s=str_replace("<", "&lt;", $s);
		$s=str_replace(">", "&gt;", $s);
		$s=str_replace("'", "&apos;", $s);
		$s=str_replace("\"", "&quot;", $s);
		return $s;
	}
}

?>